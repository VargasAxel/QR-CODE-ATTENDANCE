<?php
session_start(); // Start the session if not already started

$server = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodedb";

$conn = new mysqli($server, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['teacher_id'])) {
    $teacher_id = $_POST['teacher_id'];

    $sql_delete_teacher = "DELETE FROM teacher WHERE ID = ?";
    $stmt_delete_teacher = $conn->prepare($sql_delete_teacher);
    $stmt_delete_teacher->bind_param("s", $teacher_id);
    $stmt_delete_teacher->execute();

    if ($stmt_delete_teacher->affected_rows > 0) {
        $_SESSION['success'] = "Teacher and associated attendance records deleted successfully.";
    } else {
        $_SESSION['error'] = "An error occurred while deleting the teacher.";
    }

    $stmt_delete_teacher->close();
    $conn->close();

    header("Location: admin_teacheraccount.php");
    exit; // Exit the script after redirecting
}
?>
