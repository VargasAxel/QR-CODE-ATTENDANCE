<?php
session_start();

// Assuming this is where you handle the logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Attendance</title>
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 810px;
            margin: 20px auto;
            padding: 20px ;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Custom styles for the navbar links */
        .navbar-nav .nav-link {
            color: #fff !important;
        }
        .navbar-brand{
            color:#eee ;
        }
    </style>
</head>

<body>
    <nav class="navbar" style="background:#2c3e50">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"> <i class="glyphicon glyphicon-qrcode"></i> QR Code Attendance</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a class="nav-link" href="admin_teacher.php"><span class="glyphicon glyphicon-user"></span> Teacher / Professor List</a></li>
                <li><a class="nav-link" href="admin_teacheraccount.php"><span class="glyphicon glyphicon-list"></span> Teacher / Professor Account</a></li>
                <li><a class="nav-link" href="login.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2>Manage Teacher / Professor</h2>

        <table id="example1" class="table table-bordered table-striped">
            <thead class="thead-light">
                <tr>
                    <th>Teacher ID</th>
                    <th>Name</th>
                    <th>Subject</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $server = "localhost";
                $username = "root";
                $password = "";
                $dbname = "qrcodedb";

                $conn = new mysqli($server, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $date = date('Y-m-d');
                $sql = "SELECT * FROM teacher";
                $query = $conn->query($sql);
                while ($row = $query->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?php echo $row['ID']; ?></td>
                        <td><?php echo $row['LASTNAME'] . ', ' . $row['FIRSTNAME'] . ' ' . $row['MIDDLEINITIAL']; ?></td>
                        <td><?php echo $row['SUBJECT']; ?></td>
                        <td><?php echo $row['ROLE']; ?></td>
                        <td><?php echo $row['REG_DATE']; ?></td>    
                        <td>
                        <form action="admin_deleteteacher.php" method="post">
                        <input type="hidden" name="teacher_id" value="<?php echo $row['ID']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button></form>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    
    <script>
        $(document).ready(function () {
            var table = $("#example1").DataTable({
                "responsive": true,
                "autoWidth": false,
            });

            $('#customSearchBox').on('keyup', function () {
                table.search(this.value).draw();
            });
        });
    </script>
</body>

</html>
