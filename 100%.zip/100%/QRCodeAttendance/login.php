<?php
session_start();

$server = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodedb";

$conn = new mysqli($server, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['username'];
    $password = $_POST['password'];
    $roles = $_POST['roles'];

    if (!empty($id) && !empty($password) && !empty($roles)) {
        if ($roles == 'Teacher') {
            $query = "SELECT * FROM teacher WHERE ID = ? AND ROLE = ? LIMIT 1";
        } elseif ($roles == 'Admin') {
            $query = "SELECT * FROM admin WHERE ID = ? AND ROLE = ? LIMIT 1";
        } else {
            echo "Invalid role selected";
            exit();
        }

        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $id, $roles);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user_data = $result->fetch_assoc();
            if (password_verify($password, $user_data['PASSWORD'])) {
                $_SESSION['user_id'] = $user_data['ID'];
                $_SESSION['username'] = $user_data['FIRSTNAME'];
                if ($roles == 'Teacher') {
                    header("Location: prof_attendance.php");
                } elseif ($roles == 'Admin') {
                    header("Location: admin_teacher.php");
                }
                exit();
            } else {
                echo "Invalid password";
            }
        } else {
            echo "Invalid ID or Role";
        }
    } else {
        echo "Please input valid information";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }
        form {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        input, select, button {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            font-size: 18px;
            border: none;
        }
        button:hover {
            background-color: #45a049;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
            text-align: center;
        }
        p {
            text-align: center;
        }
        a {
            color: #4CAF50;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .password-container {
            position: relative;
        }
        .password-container input[type="password"],
        .password-container input[type="text"] {
            padding-right: 40px;
        }
        .password-container .toggle-password {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h2>Login</h2>
        <input type="text" name="username" placeholder="ID" required>
        <div class="password-container">
            <input type="password" id="password" name="password" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePassword()">👁️</span>
        </div>
        <select name="roles" required>
            <option value="">Select Role</option>
            <option value="Teacher">Teacher</option>
            <option value="Admin">Admin</option>
        </select>
        <button type="submit">Login</button>
        <p>Don't have an account? <a href="signup.php">Sign up</a></p>
    </form>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById('password');
            var toggleIcon = document.querySelector('.toggle-password');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.textContent = '🙈';
            } else {
                passwordField.type = 'password';
                toggleIcon.textContent = '👁️';
            }
        }
    </script>
</body>
</html>
